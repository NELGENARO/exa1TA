export interface Elemento {
    nombre: string,
    url: string
}